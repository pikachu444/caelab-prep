"""Native mechanical relationships shared by GUI and automation commands."""
from ..cae_core import PrepError
from ..radioss.relations import coordinate_frame, frame_block, node_support, validate_components


class ModelRelationCommands:
    def coordinate_systems(self):
        with self._lock:
            results = [coordinate_frame(self._deck_resources(), 0)]
            for card in self.list_cards():
                if not card["keyword"].upper().startswith("/SKEW/FIX/"): continue
                try:
                    results.append({**coordinate_frame(self._deck_resources(), int(card["keyword"].split("/")[3])), "name": card["title"]})
                except PrepError as exc:
                    results.append({"card_id": card["id"], "resource_id": card["resource_id"], "name": card["title"],
                                    "diagnostics": [{"code": exc.code, "message": exc.message}]})
            return results

    def _coordinate_reference(self, card_id):
        if card_id is None: return 0
        _, _, identity = self._unique_card(card_id, "SKEW")
        coordinate_frame(self._deck_resources(), identity[1])
        return identity[1]

    def create_coordinate_system(self, name, origin, y_axis, z_axis, *, resource_id=None, native_id=None,
                                 expected_revision=None, expected_document_id=None):
        with self._lock:
            self._check_model_edit(expected_revision, expected_document_id)
            resource = self._model_resource(resource_id)
            identifier = self._allocate_native_id("SKEW", native_id)
            return self._insert_model_card(resource, frame_block(identifier, name, origin, y_axis, z_axis, newline=resource.newline),
                                           "Create fixed Cartesian coordinate system", expected_revision)

    def coordinate_system_values(self, card_id):
        with self._lock:
            owner, card, identity = self._unique_card(card_id, "SKEW")
            coordinate_frame(self._deck_resources(), identity[1])
            lines = self.card_text(card_id).splitlines()
            from ..radioss.deck import number
            values = [[number(lines[index-card.start][start:start+20]) for start in (0,20,40)] for index in card.data[1:]]
            return dict(zip(("origin", "y_axis", "z_axis"), values))

    def set_coordinate_system_values(self, card_id, values, *, expected_revision=None, expected_document_id=None):
        with self._lock:
            self._check_model_edit(expected_revision, expected_document_id)
            resource, card, identity = self._unique_card(card_id, "SKEW")
            current = self.coordinate_system_values(card_id)
            if not isinstance(values, dict) or not values or set(values) - set(current):
                raise PrepError("invalid_command", "Choose origin, y_axis or z_axis.")
            merged = {**current, **values}
            validated = frame_block(identity[1], card.title, **merged).splitlines()
            lines = self.card_text(card_id).splitlines(keepends=True)
            for row, name in enumerate(("origin", "y_axis", "z_axis"), 1):
                if name not in values: continue
                index = card.data[row] - card.start
                body = lines[index].rstrip("\r\n"); ending = lines[index][len(body):]
                lines[index] = validated[row+1] + body[60:] + ending
            state = resource.replaced_state(card_id, "".join(lines))
            change = self.dispatcher.execute(resource.id, state, "Edit coordinate system", object_ids=(card_id,),
                expected_revision=expected_revision, kind="structure")
            return self._model_result(resource, card_id, change)

    def dof_support(self, node_ids):
        with self._lock:
            if not isinstance(node_ids, (tuple, list)) or not node_ids or any(type(value) is not int or value < 1 for value in node_ids):
                raise PrepError("invalid_reference", "Choose positive node IDs in the current combined native model.")
            return {"document_id": self.document.id, "revision": self.document.revision,
                    "nodes": node_support(self._deck_resources(), self.mesh_view(), node_ids),
                    "scope": "initial mechanical field applicability; not equation count or coupling verification"}

    def condition_support(self, card_id):
        with self._lock:
            values = self.condition_values(card_id)
            if "group_id" not in values: return {"status": "not-applicable", "diagnostics": []}
            direction = values.get("direction")
            translations = values.get("translations", (True,True,True) if "velocity" in values else tuple(direction == v for v in ("X","Y","Z")))
            rotations = values.get("rotations", tuple(direction == v for v in ("XX","YY","ZZ")))
            return self._validate_condition_components(values["group_id"], translations=translations, rotations=rotations,
                coordinate_system_id=values.get("coordinate_system_id"), enforce=False)

    def _validate_condition_components(self, group_id, *, translations=(False,False,False), rotations=(False,False,False), coordinate_system_id=None, enforce=True):
        native_skew_id = self._coordinate_reference(coordinate_system_id)
        resource = self._find_card(group_id)
        node_ids = self._integer_members(resource, resource.card(group_id))
        return validate_components(self._deck_resources(), self.mesh_view(), node_ids,
                                   translations=translations, rotations=rotations, native_skew_id=native_skew_id, enforce=enforce)
